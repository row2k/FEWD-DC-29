if ("city-type" === NYC){
  $("body").css(.)
}
