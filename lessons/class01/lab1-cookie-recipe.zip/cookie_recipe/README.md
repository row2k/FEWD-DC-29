Cookie Recipe CSS
=================

Colors
------

We're using the following colors on this page:

* The background color for the page is #FFE
* The color for the text reading "Related Recipes" is #887
* The link color is #900
* Bonus: The border on the page and around the image is black