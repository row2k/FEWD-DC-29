## HTML Structure and Semantics Review

Take the following content and lay it out using the HTML basics we learned last time.

=================

It's always good to have links around:
https://css-tricks.com/
https://developer.mozilla.org/en-US/docs/Web/CSS/background-position
https://www.whitehouse.gov/
http://stackoverflow.com/

Maybe you would like to read some interesting stuff today?
https://25iq.com/2016/06/18/a-dozen-things-ive-learned-from-elon-musk-about-business-and-investing/
http://www.theatlantic.com/technology/archive/2016/06/antikythera-mechanism-whoa/487832/

![Political Rally](rally.jpg)

How many days are in a week?
5
8
7
3
