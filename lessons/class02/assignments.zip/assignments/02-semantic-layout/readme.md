##Think About Structure and Semantics

Markup this page (Don't worry about 'Next in Top Stories'):
[https://www.technologyreview.com/s/601756/if-the-world-gives-up-meat-we-can-still-have-burgers/?set=601752](https://www.technologyreview.com/s/601756/if-the-world-gives-up-meat-we-can-still-have-burgers/?set=601752)

Markup the content and then go back and think beyond the just the content itself. How would you structure the page semantically - use the HTML guide and Google as needed. How would you group certain elements together?
