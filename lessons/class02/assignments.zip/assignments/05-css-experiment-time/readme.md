##CSS Experimentation

We've gone over some good properties to use but they are hard to grasp without actually using them. Included in this assignment is a  (mostly) REAL chunk of a website I've built.

###Style time

The goal here is to take 30 minutes and really get to know the world of stylesheets. Use the cheatsheet guide, notes from class and resources that have been recommended in class. Some ideas to get you going:

- Try to use font, background and text classes
- Move the images around the page
- Change the color of some of the words
- Make text align differently
