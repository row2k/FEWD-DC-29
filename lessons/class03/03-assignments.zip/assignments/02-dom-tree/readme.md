## DOM Trees

Draw the DOM tree for the PDF example.
