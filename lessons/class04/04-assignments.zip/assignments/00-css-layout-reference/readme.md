#Reference

Some nice ways to bend your brain around layouts, check the HTML / CSS.
