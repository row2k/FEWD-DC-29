#Layouts with Floats and Clears

Now that you have your feet wet a bit with float and clear, let's start putting them to use. Check out the .pdf in this folder - we're going to lay each one of these out.

We'll build the first two of these together, then it's up to you and a partner to get the rest of them done.
