//#### 1. Border around author's name ####//
//#### 2. Orange border around .author-related-news-container ####//
//#### 3. Hide each image on the page ####//
//#### 4. Make each H2 have a pink background with padding ####//
//#### 5. Make each H3 have a green background with white text ####//
