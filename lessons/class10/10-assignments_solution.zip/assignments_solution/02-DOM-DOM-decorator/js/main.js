//#### 1. Border around author's name ####//
    $(".author-name").css({"border": "red 14px solid"});

//#### 2. Orange border around .author-related-news-container ####//
    $(".author-related-news-container").css({"border": "orange 14px solid"});

//#### 3. Hide each image on the page ####//
    $("img").hide(1000);

//#### 4. Make each H2 have a pink background with padding ####//
    $(document).find("h2").css("background", "pink");

//#### 5. Make each H3 have a green background with white text ####//
    $("h3").css({"background-color": "green",
        "color":"white"
        });
